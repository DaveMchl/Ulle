Content Manager (0.8.1869.35097)

    Installation:
    - Unpack "Content Manager.exe" anywhere;
    - That's all.

    It's better to use some not read-only location, so app will be able to 
auto-update itself periodically.

    Don't forget to go to settings and install all addons you want. I didn't 
include them into main exe-file, otherwise it'd be way too big.
